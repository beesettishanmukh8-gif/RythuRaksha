import fs from "node:fs";
import path from "node:path";

export function ensurePwaAssets() {
  const dir = path.resolve(process.cwd(), "public");
  fs.mkdirSync(dir, { recursive:true });
  const icon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="112" fill="#064e3b"/><path d="M390 104C250 108 132 150 112 278c-13 82 47 137 116 126 112-18 156-159 162-300Z" fill="#86efac"/><path d="M112 400c65-111 143-174 250-245" fill="none" stroke="#064e3b" stroke-width="22" stroke-linecap="round"/><path d="M116 405c-5-71-35-108-76-134 1 71 22 120 76 134Z" fill="#d1fae5"/></svg>`;
  fs.writeFileSync(path.join(dir,"icon.svg"),icon);
  fs.writeFileSync(path.join(dir,"apple-touch-icon.svg"),icon);
}
