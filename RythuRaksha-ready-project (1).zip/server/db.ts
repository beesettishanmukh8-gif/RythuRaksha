import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

export interface UserRecord {
  id: string; phone: string; email?: string; passwordHash?: string; name: string;
  district: string; state: string; primaryCrops: string[]; preferredLanguage: string;
  authProvider?: string; resetToken?: string; resetExpires?: number;
}
type Crop = { id:string; userId:string; cropName:string; variety:string; acreage:number; sowingDate:string; stage:string; expectedHarvestDate:string; healthStatus:string; notes:string; };
type Expense = { id:string; userId:string; cropId?:string; cropName:string; type:"INCOME"|"EXPENSE"; category:string; amount:number; date:string; notes:string; };
type Reminder = { id:string; userId:string; cropId?:string; cropName:string; title:string; category:string; dueDate:string; dueTime:string; isCompleted:boolean; notes:string; };
type Listing = { id:string; userId:string; sellerName:string; sellerPhone:string; district:string; state:string; title:string; category:string; price:number; unit:string; description:string; createdAt:string; };
type Diagnosis = { id:string; userId:string; cropName:string; diagnosisTitle:string; severityLevel:string; status:string; timestamp:number; farmerNotes:string; fullReport:any; };
type Store = { users:UserRecord[]; sessions:Record<string,string>; crops:Crop[]; expenses:Expense[]; reminders:Reminder[]; listings:Listing[]; diagnoses:Diagnosis[]; };

const dataDir = path.resolve(process.cwd(), "data");
const file = path.join(dataDir, "db.json");
fs.mkdirSync(dataDir, { recursive:true });
const empty:Store = { users:[], sessions:{}, crops:[], expenses:[], reminders:[], listings:[], diagnoses:[] };
function load():Store {
  try { return { ...empty, ...JSON.parse(fs.readFileSync(file,"utf8")) }; }
  catch { return structuredClone(empty); }
}
let store:Store = load();
function save(){ fs.writeFileSync(file, JSON.stringify(store,null,2), "utf8"); }
function id(prefix:string){ return `${prefix}_${crypto.randomUUID()}`; }
export function hashPassword(value:string){ return crypto.createHash("sha256").update(value).digest("hex"); }

export const db = {
  getUserByPhone(phone:string){ return store.users.find(x=>x.phone===phone); },
  getUserByEmail(email:string){ return store.users.find(x=>x.email?.toLowerCase()===email.toLowerCase()); },
  getUserById(userId:string){ return store.users.find(x=>x.id===userId); },
  getUserByToken(token:string){ const uid=store.sessions[token]; return uid ? this.getUserById(uid) : undefined; },
  createUser(input:Omit<UserRecord,"id"> & {id?:string}) {
    const user={...input,id:input.id || id("user")}; store.users.push(user); save(); return user;
  },
  updateUser(userId:string, patch:Partial<UserRecord>){ const i=store.users.findIndex(x=>x.id===userId); if(i<0)return undefined; store.users[i]={...store.users[i],...patch}; save(); return store.users[i]; },
  createSession(userId:string){ const token=crypto.randomBytes(32).toString("hex"); store.sessions[token]=userId; save(); return token; },
  destroySession(token:string){ delete store.sessions[token]; save(); },
  getCrops(userId:string){ return store.crops.filter(x=>x.userId===userId); },
  addCrop(input:Omit<Crop,"id">){ const x={...input,id:id("crop")}; store.crops.push(x); save(); return x; },
  updateCrop(cropId:string,userId:string,patch:Partial<Crop>){ const i=store.crops.findIndex(x=>x.id===cropId&&x.userId===userId); if(i<0)return undefined; store.crops[i]={...store.crops[i],...patch,id:cropId,userId}; save(); return store.crops[i]; },
  deleteCrop(cropId:string,userId:string){ const n=store.crops.length; store.crops=store.crops.filter(x=>!(x.id===cropId&&x.userId===userId)); save(); return n!==store.crops.length; },
  getExpenses(userId:string){ return store.expenses.filter(x=>x.userId===userId); },
  addExpense(input:Omit<Expense,"id">){ const x={...input,id:id("txn")}; store.expenses.push(x); save(); return x; },
  deleteExpense(expenseId:string,userId:string){ const n=store.expenses.length; store.expenses=store.expenses.filter(x=>!(x.id===expenseId&&x.userId===userId)); save(); return n!==store.expenses.length; },
  getReminders(userId:string){ return store.reminders.filter(x=>x.userId===userId); },
  addReminder(input:Omit<Reminder,"id">){ const x={...input,id:id("rem")}; store.reminders.push(x); save(); return x; },
  updateReminder(reminderId:string,userId:string,patch:Partial<Reminder>){ const i=store.reminders.findIndex(x=>x.id===reminderId&&x.userId===userId); if(i<0)return undefined; store.reminders[i]={...store.reminders[i],...patch}; save(); return store.reminders[i]; },
  deleteReminder(reminderId:string,userId:string){ const n=store.reminders.length; store.reminders=store.reminders.filter(x=>!(x.id===reminderId&&x.userId===userId)); save(); return n!==store.reminders.length; },
  getMarketplaceListings(category?:string){ return store.listings.filter(x=>!category||category==="ALL"||x.category===category).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)); },
  addMarketplaceListing(input:Omit<Listing,"id"|"createdAt">){ const x={...input,id:id("listing"),createdAt:new Date().toISOString()}; store.listings.push(x); save(); return x; },
  deleteMarketplaceListing(listingId:string,userId:string){ const n=store.listings.length; store.listings=store.listings.filter(x=>!(x.id===listingId&&x.userId===userId)); save(); return n!==store.listings.length; },
  getDiagnoses(userId:string){ return store.diagnoses.filter(x=>x.userId===userId).sort((a,b)=>b.timestamp-a.timestamp); },
  saveDiagnosis(input:Omit<Diagnosis,"id">){ const x={...input,id:id("diag")}; store.diagnoses.push(x); save(); return x; },
  updateDiagnosisStatus(diagnosisId:string,userId:string,status:string,notes?:string){ const x=store.diagnoses.find(x=>x.id===diagnosisId&&x.userId===userId); if(!x)return false; x.status=status; if(notes!==undefined)x.farmerNotes=notes; save(); return true; }
};
