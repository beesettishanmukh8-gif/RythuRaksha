# RythuRaksha – Crop Leaf Doctor

A React + Vite + Express starter application for farmers. It includes crop records, farm expenses, reminders, Open-Meteo weather, and Gemini-powered crop photo diagnosis and Q&A.

## Requirements
- Node.js 20.19+ or 22.12+ (Vite 8 requirement)
- npm
- A Gemini API key for AI diagnosis and Q&A

## Run on Windows
1. Extract this project ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal → New Terminal.
4. Run `npm install`.
5. Copy `.env.example` to `.env` and add your Gemini API key:
   `GEMINI_API_KEY=your_real_key`
6. Run `npm run dev`.
7. Open `http://localhost:3000`.

## Build
- `npm run build`
- `npm start` (serves the production build after building)

## Notes before public launch
- The included JSON database is a simple single-server starter, not a production database.
- The demo UI uses a fixed local demo user ID. Add real authentication and per-user authorization before public deployment.
- OTP is simulated in the supplied server code; it does not send SMS. Do not use it for real accounts.
- Mandi price endpoint deliberately returns an empty list until a verified provider/API is configured; do not treat placeholder prices as live.
- AI crop diagnosis is advisory, not a substitute for a local KVK/agricultural officer. Confirm pesticide labels, registrations, dosage and pre-harvest intervals before spraying.
- Never commit `.env` or expose the Gemini API key in frontend code.
