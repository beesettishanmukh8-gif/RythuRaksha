import { useEffect, useMemo, useState } from "react";

type Crop = { id:string; cropName:string; variety?:string; acreage:number; stage:string; healthStatus:string; sowingDate:string; };
type Report = any;
const USER_ID = "rythu-demo-farmer";
const headers = { "Content-Type":"application/json", "x-user-id":USER_ID };
async function api<T=any>(url:string, init:RequestInit={}):Promise<T>{
  const mergedHeaders = new Headers(headers);
  new Headers(init.headers).forEach((value, key) => mergedHeaders.set(key, value));
  const res=await fetch(url,{...init,headers:mergedHeaders});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.error||`Request failed (${res.status})`);
  return data;
}
const money=(n:number)=>new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n||0);

export default function App(){
  const [tab,setTab]=useState("home");
  const [crops,setCrops]=useState<Crop[]>([]);
  const [expenses,setExpenses]=useState<any[]>([]);
  const [reminders,setReminders]=useState<any[]>([]);
  const [weather,setWeather]=useState<any>(null);
  const [district,setDistrict]=useState("Guntur");
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  const [toast,setToast]=useState("");
  const [photo,setPhoto]=useState<File|null>(null);
  const [preview,setPreview]=useState("");
  const [report,setReport]=useState<Report|null>(null);
  const [cropForm,setCropForm]=useState({cropName:"Paddy",variety:"",acreage:"1",sowingDate:new Date().toISOString().slice(0,10)});
  const [expenseForm,setExpenseForm]=useState({cropName:"General",type:"EXPENSE",category:"Seeds",amount:"",date:new Date().toISOString().slice(0,10),notes:""});
  const [reminderForm,setReminderForm]=useState({title:"",dueDate:new Date().toISOString().slice(0,10),dueTime:"07:00",category:"IRRIGATION"});
  const [question,setQuestion]=useState("");
  const [answer,setAnswer]=useState<any>(null);

  async function refresh(){
    try{
      const [c,e,r,w]=await Promise.all([
        api<any>(`/api/crops?userId=${USER_ID}`),api<any>(`/api/expenses?userId=${USER_ID}`),api<any>(`/api/reminders?userId=${USER_ID}`),
        api<any>(`/api/weather?name=${encodeURIComponent(district+", Andhra Pradesh")}`)
      ]);
      setCrops(c.crops||[]);setExpenses(e.expenses||[]);setReminders(r.reminders||[]);setWeather(w);
    }catch(err:any){setError(err.message);}
  }
  useEffect(()=>{refresh();},[]);
  const totals=useMemo(()=>({
    income:expenses.filter(x=>x.type==="INCOME").reduce((s,x)=>s+x.amount,0),
    spend:expenses.filter(x=>x.type==="EXPENSE").reduce((s,x)=>s+x.amount,0)
  }),[expenses]);
  function notify(s:string){setToast(s);window.setTimeout(()=>setToast(""),2800);}
  async function addCrop(e:React.FormEvent){e.preventDefault();try{await api("/api/crops",{method:"POST",body:JSON.stringify({...cropForm,acreage:Number(cropForm.acreage),userId:USER_ID})});setCropForm({cropName:"Paddy",variety:"",acreage:"1",sowingDate:new Date().toISOString().slice(0,10)});await refresh();notify("Crop saved");}catch(x:any){setError(x.message);}}
  async function addExpense(e:React.FormEvent){e.preventDefault();try{await api("/api/expenses",{method:"POST",body:JSON.stringify({...expenseForm,amount:Number(expenseForm.amount),userId:USER_ID})});setExpenseForm({...expenseForm,amount:"",notes:""});await refresh();notify("Transaction saved");}catch(x:any){setError(x.message);}}
  async function addReminder(e:React.FormEvent){e.preventDefault();try{await api("/api/reminders",{method:"POST",body:JSON.stringify({...reminderForm,userId:USER_ID})});setReminderForm({...reminderForm,title:""});await refresh();notify("Reminder added");}catch(x:any){setError(x.message);}}
  async function diagnose(e:React.FormEvent){e.preventDefault();if(!photo)return;if(photo.size>15*1024*1024){setError("Please choose an image smaller than 15 MB.");return;}setBusy(true);setError("");setReport(null);try{
    const dataUrl=await new Promise<string>((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=reject;r.readAsDataURL(photo);});
    const result=await api<Report>("/api/diagnose",{method:"POST",body:JSON.stringify({imageBase64:dataUrl,mimeType:photo.type||"image/jpeg",cropHint:"Auto Detect",preferredLang:"te",locationDistrict:district,locationState:"Andhra Pradesh"})});
    setReport(result);
    await api("/api/diagnoses",{method:"POST",body:JSON.stringify({report:result,cropName:result.cropName?.en,diagnosisTitle:result.diagnosisTitle?.en,severityLevel:result.severityLevel,userId:USER_ID})});
    notify("AI diagnosis completed and saved");
  }catch(x:any){setError(x.message);}finally{setBusy(false);}}
  async function ask(e:React.FormEvent){e.preventDefault();if(!question.trim())return;setBusy(true);try{setAnswer(await api("/api/ask",{method:"POST",body:JSON.stringify({question,diagnosisContext:report,language:"te"})}));}catch(x:any){setError(x.message);}finally{setBusy(false);}}
  async function toggleReminder(id:string){try{await api(`/api/reminders/${id}/toggle`,{method:"PATCH",body:JSON.stringify({userId:USER_ID})});await refresh();}catch(x:any){setError(x.message);}}
  async function remove(url:string){try{await api(url,{method:"DELETE"});await refresh();notify("Deleted");}catch(x:any){setError(x.message);}}

  const nav=[["home","⌂","Overview"],["diagnose","✿","AI Doctor"],["crops","♧","My Crops"],["money","₹","Farm Ledger"],["reminders","◷","Reminders"]];
  return <div className="app-shell">
    <header className="topbar"><div className="brand"><div className="brand-mark">🌱</div><div><strong>RythuRaksha</strong><small>రైతు రక్ష · Farmer's companion</small></div></div><div className="location"><span>📍</span><input value={district} onChange={e=>setDistrict(e.target.value)} onBlur={refresh} aria-label="District" /></div></header>
    <main className="container">
      <section className="welcome"><div><span className="eyebrow">మీ వ్యవసాయ సహాయకుడు</span><h1>Good day, Farmer! <span>🌾</span></h1><p>Know your crop. Protect your harvest.</p></div><div className="date-chip">{new Date().toLocaleDateString("en-IN",{weekday:"short",day:"numeric",month:"short"})}</div></section>
      {error&&<div className="alert"><span>{error}</span><button onClick={()=>setError("")}>✕</button></div>}
      {toast&&<div className="toast">{toast}</div>}
      <nav className="tabs">{nav.map(([id,icon,label])=><button key={id} className={tab===id?"active":""} onClick={()=>setTab(id)}><span>{icon}</span>{label}</button>)}</nav>
      {tab==="home"&&<><section className="stats">
        <article className="stat-card"><span>🌿 Active crops</span><b>{crops.length}</b><small>In your farm</small></article>
        <article className="stat-card"><span>💸 Total expenses</span><b>{money(totals.spend)}</b><small>Recorded spending</small></article>
        <article className="stat-card"><span>📈 Net balance</span><b className={totals.income-totals.spend>=0?"positive":"negative"}>{money(totals.income-totals.spend)}</b><small>Income minus expenses</small></article>
      </section>
      <div className="two-col"><section className="panel weather-panel"><div className="panel-head"><div><span className="eyebrow">LOCAL WEATHER</span><h2>Field conditions</h2></div><span className="weather-icon">⛅</span></div>{weather?.current?<><div className="temperature">{Math.round(weather.current.temperature_2m)}°<small>C</small></div><p>Feels like {Math.round(weather.current.apparent_temperature)}°C · {weather.current.relative_humidity_2m}% humidity</p><div className="weather-meta"><span>💨 {weather.current.wind_speed_10m} km/h wind</span><span>🌧️ {weather.current.precipitation} mm rain</span></div><small className="muted">Source: Open-Meteo · {weather.location}</small></>:<p>Weather is loading or unavailable.</p>}</section>
      <section className="panel"><div className="panel-head"><div><span className="eyebrow">QUICK ACTIONS</span><h2>What do you need?</h2></div></div><div className="quick-grid"><button onClick={()=>setTab("diagnose")}>📷<b>Check crop health</b><small>Upload a photo</small></button><button onClick={()=>setTab("crops")}>🌱<b>Add a crop</b><small>Track your fields</small></button><button onClick={()=>setTab("money")}>₹<b>Farm accounts</b><small>Income & expenses</small></button><button onClick={()=>setTab("reminders")}>🔔<b>Set reminder</b><small>Never miss a task</small></button></div></section></div>
      <section className="panel"><div className="panel-head"><div><span className="eyebrow">YOUR FARM</span><h2>Crop snapshot</h2></div><button className="text-button" onClick={()=>setTab("crops")}>View all →</button></div>{crops.length?<div className="crop-list">{crops.slice(0,4).map(c=><div className="crop-row" key={c.id}><div className="crop-avatar">🌾</div><div className="grow"><b>{c.cropName}</b><small>{c.variety||"Variety not set"} · {c.acreage} acre(s)</small></div><span className="status">{c.healthStatus||"HEALTHY"}</span></div>)}</div>:<Empty text="No crops added yet. Add your first crop to start tracking your farm."/>}</section></>}
      {tab==="diagnose"&&<section className="panel wide-panel"><span className="eyebrow">AI CROP HEALTH SCANNER</span><h2>Ask your AI Crop Doctor</h2><p className="muted">Take a clear photo of the affected leaf, stem, fruit, or whole plant.</p><form onSubmit={diagnose} className="diagnose-form"><label className="upload-box">{preview?<img src={preview} alt="Selected crop" />:<><span className="upload-icon">📸</span><b>Choose a crop photo</b><small>JPG, PNG or WebP · Max 15 MB</small></>}<input type="file" accept="image/*" capture="environment" onChange={e=>{const f=e.target.files?.[0];if(f){setPhoto(f);setPreview(URL.createObjectURL(f));}}}/></label><button className="primary" disabled={!photo||busy}>{busy?"Analyzing crop…":"🔍 Diagnose my crop"}</button></form>
      {report&&<div className="report"><div className="report-head"><div><span className="eyebrow">DIAGNOSIS REPORT</span><h3>{report.diagnosisTitle?.en||"Crop analysis"}</h3><p>{report.cropName?.en} · {report.severityLevel}</p></div><span className="confidence">{Math.round((report.confidenceScore||0)*100)}%<small>confidence</small></span></div><p>{report.shortSummary?.en}</p><h4>Recommended first step</h4><p>{report.treatment?.immediateAction?.en}</p><h4>Organic treatments</h4>{(report.treatment?.organicTreatments||[]).map((x:any,i:number)=><p key={i}><b>{x.methodName?.en}</b> — {x.dosage?.en}. {x.instructions?.en}</p>)}<h4>Important safety note</h4><p>AI results are preliminary. Confirm diagnosis and pesticide choice with a local agricultural officer or KVK before spraying. Follow the product label and local regulations.</p><form onSubmit={ask} className="ask-form"><input value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Ask a follow-up question…" /><button className="primary" disabled={busy}>Ask</button></form>{answer&&<div className="answer"><b>తెలుగు</b><p>{answer.answerLocal}</p><b>English</b><p>{answer.answerEn}</p></div>}</div>}
      </section>}
      {tab==="crops"&&<div className="two-col align-start"><section className="panel"><span className="eyebrow">FIELD REGISTER</span><h2>Add a crop</h2><form className="stack-form" onSubmit={addCrop}><label>Crop name<input required value={cropForm.cropName} onChange={e=>setCropForm({...cropForm,cropName:e.target.value})}/></label><label>Variety<input value={cropForm.variety} onChange={e=>setCropForm({...cropForm,variety:e.target.value})} placeholder="e.g. BPT 5204"/></label><label>Area (acres)<input required type="number" min="0.1" step="0.1" value={cropForm.acreage} onChange={e=>setCropForm({...cropForm,acreage:e.target.value})}/></label><label>Sowing date<input type="date" value={cropForm.sowingDate} onChange={e=>setCropForm({...cropForm,sowingDate:e.target.value})}/></label><button className="primary">Save crop</button></form></section><section className="panel"><span className="eyebrow">MY FIELDS</span><h2>Your crops ({crops.length})</h2>{crops.length?crops.map(c=><div className="crop-row" key={c.id}><div className="crop-avatar">🌱</div><div className="grow"><b>{c.cropName}</b><small>{c.variety||"No variety"} · {c.acreage} acres · {c.stage}</small></div><button className="icon-button" onClick={()=>remove(`/api/crops/${c.id}?userId=${USER_ID}`)}>🗑</button></div>):<Empty text="Your crop list is empty."/>}</section></div>}
      {tab==="money"&&<div className="two-col align-start"><section className="panel"><span className="eyebrow">FARM LEDGER</span><h2>Record transaction</h2><form className="stack-form" onSubmit={addExpense}><label>Type<select value={expenseForm.type} onChange={e=>setExpenseForm({...expenseForm,type:e.target.value})}><option value="EXPENSE">Expense</option><option value="INCOME">Income</option></select></label><label>Category<input value={expenseForm.category} onChange={e=>setExpenseForm({...expenseForm,category:e.target.value})}/></label><label>Crop / description<input value={expenseForm.cropName} onChange={e=>setExpenseForm({...expenseForm,cropName:e.target.value})}/></label><label>Amount (₹)<input type="number" min="1" required value={expenseForm.amount} onChange={e=>setExpenseForm({...expenseForm,amount:e.target.value})}/></label><label>Date<input type="date" value={expenseForm.date} onChange={e=>setExpenseForm({...expenseForm,date:e.target.value})}/></label><label>Notes<input value={expenseForm.notes} onChange={e=>setExpenseForm({...expenseForm,notes:e.target.value})}/></label><button className="primary">Save transaction</button></form></section><section className="panel"><span className="eyebrow">CASH FLOW</span><h2>Farm accounts</h2><div className="ledger-summary"><div><small>Income</small><b className="positive">{money(totals.income)}</b></div><div><small>Expenses</small><b className="negative">{money(totals.spend)}</b></div></div>{expenses.length?expenses.slice().reverse().map(x=><div className="crop-row" key={x.id}><div className="grow"><b>{x.cropName}</b><small>{x.category} · {x.date}</small></div><b className={x.type==="INCOME"?"positive":"negative"}>{x.type==="INCOME"?"+":"−"}{money(x.amount)}</b><button className="icon-button" onClick={()=>remove(`/api/expenses/${x.id}?userId=${USER_ID}`)}>🗑</button></div>):<Empty text="No transactions recorded yet."/>}</section></div>}
      {tab==="reminders"&&<div className="two-col align-start"><section className="panel"><span className="eyebrow">FARM TASK PLANNER</span><h2>Create a reminder</h2><form className="stack-form" onSubmit={addReminder}><label>Task<input required value={reminderForm.title} onChange={e=>setReminderForm({...reminderForm,title:e.target.value})} placeholder="e.g. Irrigate paddy field"/></label><label>Category<select value={reminderForm.category} onChange={e=>setReminderForm({...reminderForm,category:e.target.value})}><option value="IRRIGATION">Irrigation</option><option value="FERTILIZER">Fertilizer</option><option value="SPRAYING">Spraying</option><option value="HARVEST">Harvest</option><option value="OTHER">Other</option></select></label><label>Date<input type="date" value={reminderForm.dueDate} onChange={e=>setReminderForm({...reminderForm,dueDate:e.target.value})}/></label><label>Time<input type="time" value={reminderForm.dueTime} onChange={e=>setReminderForm({...reminderForm,dueTime:e.target.value})}/></label><button className="primary">Add reminder</button></form></section><section className="panel"><span className="eyebrow">UPCOMING WORK</span><h2>Farm reminders</h2>{reminders.length?reminders.map(r=><div className="reminder-row" key={r.id}><input type="checkbox" checked={r.isCompleted} onChange={()=>toggleReminder(r.id)}/><div className="grow"><b className={r.isCompleted?"done":""}>{r.title}</b><small>{r.category} · {r.dueDate} at {r.dueTime}</small></div><button className="icon-button" onClick={()=>remove(`/api/reminders/${r.id}?userId=${USER_ID}`)}>🗑</button></div>):<Empty text="No reminders yet. Add your next farm task."/>}</section></div>}
      <footer>RythuRaksha · Built to support farmers · AI advice should be verified locally before treatment.</footer>
    </main>
  </div>
}
function Empty({text}:{text:string}){return <div className="empty"><span>🌾</span><p>{text}</p></div>}
