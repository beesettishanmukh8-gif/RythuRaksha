export async function fetchAgriWeather(lat:number, lon:number, name:string) {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.search = new URLSearchParams({
    latitude:String(lat), longitude:String(lon),
    current:"temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m",
    daily:"temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum",
    timezone:"auto", forecast_days:"3"
  }).toString();
  const response = await fetch(url);
  if(!response.ok) throw new Error(`Weather provider returned ${response.status}`);
  const data:any = await response.json();
  return { location:name, current:data.current, daily:data.daily, source:"Open-Meteo", updatedAt:new Date().toISOString() };
}

// No public, stable mandi feed is configured in this starter. Return an explicit
// empty result rather than inventing prices or presenting sample values as live.
export function getMandiPrices(_district?:string, _query?:string) {
  return [];
}
