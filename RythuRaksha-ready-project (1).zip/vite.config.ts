import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import path from "node:path";
import { defineConfig } from "vite";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    VitePWA({
      registerType: "autoUpdate",
      manifest: {
        id: "/",
        name: "RythuRaksha - Crop Leaf Doctor",
        short_name: "RythuRaksha",
        description: "AI crop health guidance and farm management for farmers.",
        theme_color: "#064e3b",
        background_color: "#f3f7f2",
        display: "standalone",
        start_url: "/",
        scope: "/",
        icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any maskable" }]
      }
    })
  ],
  resolve: { alias: { "@": path.resolve(process.cwd(), ".") } },
  server: { host: "0.0.0.0", port: 3000 }
});
